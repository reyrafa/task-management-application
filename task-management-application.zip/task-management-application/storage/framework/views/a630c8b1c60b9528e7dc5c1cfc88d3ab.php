<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('My Tasks')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="mt-7 container mx-auto p-5">
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="bg-green-200 text-green-700  rounded shadow-lg p-5 mb-3"><?php echo e(session('success')); ?></div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <div class="flex justify-end">
            <a href="<?php echo e(route('tasks.create')); ?>"
                class="bg-green-800 rounded shadow-lg text-green-200 px-5 py-2 hover:bg-green-500 hover:text-green-800"><?php echo e(__('Create Task')); ?></a>

        </div>
        <div class="mt-5">
            <?php if(empty($events)): ?>
                <h2>No tasks yet.</h2>
            <?php else: ?>
                <div class="block md:flex gap-5">
                    <div class="bg-white p-10 rounded shadow md:w-3/4 mb-4">
                        <div class="mb-5 flex justify-end">
                            <div>
                                <h2 class="text-stone-800 font-bold tracking-wide text-end">Legend</h2>
                                <div class="flex gap-5 mt-1">
                                    <div class="flex gap-2 items-center">
                                        <label for="low_priority" class="text-stone-500"><?php echo e(__('Low Priority')); ?></label>
                                        <div class="px-2 h-2 bg-stone-500 w-5" id="low_priority"></div>

                                    </div>
                                    <div class="flex gap-2 items-center">
                                        <label for="high_priority" class="text-red-600"><?php echo e(__('High Priority')); ?></label>
                                        <div class="px-2 h-2 bg-red-600 w-5" id="high_priority"></div>

                                    </div>
                                </div>
                            </div>

                        </div>
                        <div id="calendar"></div>
                    </div>
                    <div class="grow">
                        <div class="bg-white p-5 shadow-lg rounded mb-5">
                            <div>
                                <h2 class="tracking-wider font-bold text-red-500 mb-2 uppercase">Urgent Tasks</h2>
                                <ul class="list-disc list-inside">
                                    <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $urgent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-2 text-sm"><a href="<?php echo e(route('tasks.show', $urgent->uuid)); ?>"
                                                class="hover:text-red-400">
                                                <?php echo e($urgent->title . __(' (Due on ') . $urgent->due_date . __(')')); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <div class="bg-white p-5 shadow-lg rounded">
                            <div>
                                <h2 class="tracking-wider font-bold text-stone-700 mb-2 uppercase">Latest Completed Tasks
                                </h2>
                                <ul class="list-disc list-inside">
                                    <?php $__currentLoopData = $done_tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $done_task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="mb-2 text-sm"><a href="<?php echo e(route('tasks.show', $done_task->uuid)); ?>"
                                                class="hover:text-green-400">
                                                <?php echo e($done_task->title); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('calendar');
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'dayGridMonth',
                    events: <?php echo json_encode($events, 15, 512) ?>,
                    headerToolbar: {
                        left: 'prev next',
                        center: 'title',
                        right: 'dayGridMonth multiMonthYear'
                    },
                    height: 650,
                    contentHeight: 600,

                    selectable: true,
                    eventClick: function(info) {
                        window.location.href =
                            `<?php echo e(route('tasks.show', '')); ?>/${info.event.extendedProps.task}`;
                    },
                    eventDidMount: function(info) {
                        info.el.style.padding = '10px';
                        info.el.style.cursor = 'pointer';

                        info.el.addEventListener('mouseover', () => {

                            info.el.style.backgroundColor = info.event.extendedProps.priority ===
                                'low' ? '#999999' : '#ff3232';

                        });
                        info.el.addEventListener('mouseout', () => {
                            info.el.style.backgroundColor = info.event.backgroundColor;
                        });


                    }


                });
                calendar.render();
            })
        </script>
    <?php $__env->stopPush(); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\resources\views/tasks/index.blade.php ENDPATH**/ ?>