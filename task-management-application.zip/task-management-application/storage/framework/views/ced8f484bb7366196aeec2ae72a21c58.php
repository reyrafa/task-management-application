<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('My Categories')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="mt-7 container mx-auto p-5">
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="bg-green-500 text-white p-4 rounded shadow mb-4" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <div class="flex justify-end mb-3">
            <a href="<?php echo e(route('categories.create')); ?>"
                class="py-1 px-5 bg-blue-800 text-white rounded uppercase tracking-wider">Add Category</a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white mb-5 rounded p-5">
                <div class="uppercase text-lg font-bold text-gray-900"><?php echo e($category->name); ?></div>
                <div class="text-sm text-gray-600">Created On <?php echo e(date('Y-m-d', strtotime($category->created_at))); ?>

                </div>
                <div class="mt-3 flex gap-2 items-center">
                    <div><a href="<?php echo e(route('categories.edit', $category->id)); ?>"
                            class="bg-blue-700 text-blue-100 rounded px-3 py-1 text-sm block"><?php echo e(__('Update')); ?></a>
                    </div>
                    <div x-data>

                        <button class="bg-red-700 text-red-100 rounded px-3 py-1 text-sm block"
                            x-on:click="$dispatch('open-modal', { name: 'confirm-category-deletion', category_id: <?php echo e($category->id); ?> })"><?php echo e(__('Delete')); ?></button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="text-sm text-gray-800">No Categories Yet.</div>
        <?php endif; ?>

    </div>
    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'confirm-category-deletion','show' => $errors->has('password')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'confirm-category-deletion','show' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->has('password'))]); ?>
        <div x-data="{ category_id: '<?php echo e(old('category_id')); ?>' }" class="p-6"
            x-on:open-modal.window="
                if($event.detail.name === 'confirm-category-deletion'){
                    category_id = $event.detail.category_id
                }">

            <form method="post" :action="`<?php echo e(route('categories.destroy', '')); ?>/${category_id}`">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>

                <h2 class=" text-lg font-medium text-gray-900">
                    <?php echo e(__('Are you sure you want to delete this category?')); ?></h2>

                <input type="hidden" name="category_id" :value="category_id">


                <p class="mt-1 text-gray-600">
                    <?php echo e(__('Please enter your password to confirm you would like to permanently delete your category.')); ?>

                </p>
                <div class="mt-3">
                    <input type="password" placeholder="Password" name="password"
                        class="w-3/4 rounded-md border-slate-300 focus:border-slate-500 focus:ring-slate-600 shadow">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-red-500 mt-2 text-sm"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mt-5 flex justify-end gap-3">

                    <button x-on:click="$dispatch('close')" type="button"
                        class="px-5 py-1 uppercase text-sm tracking-wider hover:bg-slate-100 bg-white border border-slate-300 rounded"><?php echo e(__('Close')); ?></button>
                    <button
                        class="px-5 py-1 uppercase text-sm rounded tracking-wider bg-red-600 text-white hover:bg-red-500"
                        type="submit"><?php echo e(__('Delete')); ?></button>
                </div>
            </form>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\resources\views/categories/index.blade.php ENDPATH**/ ?>