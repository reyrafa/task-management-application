<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Show Task')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('My Task')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="mt-7 container mx-auto p-5">
        <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="bg-red-700 text-red-100 p-4 rounded shadow mb-2 flex items-center justify-between" role="alert">
                <div>
                    <?php echo e(session('error')); ?>

                </div>
                <div class="">
                    <button type="button" onclick="this.parentElement.parentElement.remove()"
                        class="text-2xl text-red-100 hover:text-red-200 font-bold">
                        &times;
                    </button>
                </div>

            </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="bg-green-700 text-green-100 p-4 rounded shadow mb-2 flex items-center justify-between"
                role="alert">
                <div>
                    <?php echo e(session('success')); ?>

                </div>
                <div class="">
                    <button type="button" onclick="this.parentElement.parentElement.remove()"
                        class="text-2xl text-green-100 hover:text-green-200 font-bold">
                        &times;
                    </button>
                </div>

            </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <?php if(auth()->user()->id === $task->user_id): ?>
            <div class="bg-white p-5 rounded">
                <div class="flex justify-between">
                    <div>
                        <div class="font-bold tracking-wider text-stone-700 uppercase text-lg"><?php echo e($task->title); ?>

                            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                                'text-base',
                                'text-orange-500' => $task->status === 'pending',
                                'text-blue-500' => $task->status === 'ongoing',
                                'text-green-500' => $task->status === 'done',
                            ]); ?>"><?php echo e(__('(') . $task->status . __(')')); ?></span>
                        </div>
                        <div class="text-stone-600 tracking-wide"><?php echo e(ucwords($task->category->name)); ?></div>
                        <div class="text-stone-600 text-sm tracking-wide">
                            <?php echo e(\Carbon\Carbon::parse($task->start_date)->format('M d, Y')); ?> -
                            <?php echo e(\Carbon\Carbon::parse($task->due_date)->format('M d, Y')); ?></div>
                        <div class="mt-3 text-stone-600 font-bold"><?php echo e(__('Details')); ?></div>
                        <div class="indent-10 tracking-wide text-stone-700"><?php echo e(ucwords($task->description)); ?></div>
                    </div>
                    <div>
                        <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'text-red-700' => $task->priority === 'high',
                            'text-stone-700' => $task->priority === 'low',
                            'tracking-widest uppercase p-2 rounded',
                        ]); ?>"><?php echo e($task->priority); ?></div>
                    </div>
                </div>
                <div class="mt-3">
                    <div class="text-stone-600 font-bold"><?php echo e(__('Notes')); ?></div>
                    <div>
                        <ul class="list-disc list-inside text-gray-700">
                            <?php $__currentLoopData = $task->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="indent-5"><?php echo e($note->note); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </ul>
                    </div>
                </div>
                <div class="mt-10">
                    <div>
                        <form action="<?php echo e(route('tasks.store_note', $task->uuid)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <textarea class="w-full rounded" rows="5" name="note" name="" id=""
                                placeholder="Write down notes.."></textarea>
                            <button type="submit"
                                class="py-2 px-4 bg-green-700 rounded mt-2 shadow text-green-50"><?php echo e(__('Submit Note')); ?></button>
                        </form>

                    </div>
                </div>
                <div class="mt-4 flex justify-end gap-4">

                    <div class="flex gap-5">
                        <a href="<?php echo e(route('tasks.edit', $task->uuid)); ?>"
                            class="bg-blue-700 py-2 px-4 rounded text-blue-100 text-sm hover:bg-blue-500"><?php echo e(__('Update')); ?></a>
                        <?php if($task->status !== 'done'): ?>
                            <form action="<?php echo e(route('tasks.update_task_status', $task->uuid)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                                <button type="submit"
                                    class="bg-green-700 py-2 px-4 rounded text-green-100 text-sm hover:bg-green-500"><?php echo e($task->status === 'pending' ? __('Do') : __('Done')); ?></button>
                            </form>
                        <?php endif; ?>
                    </div>

                </div>

            </div>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\resources\views/tasks/show.blade.php ENDPATH**/ ?>