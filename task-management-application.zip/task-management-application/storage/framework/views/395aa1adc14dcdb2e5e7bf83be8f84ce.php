<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['action', 'update' => false, 'task' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['action', 'update' => false, 'task' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white p-10 w-3/4 rounded mx-auto shadow-lg">
    <form action="<?php echo e($action); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php if($update): ?>
            <?php echo method_field('put'); ?>
        <?php endif; ?>
        <div class="block md:grid md:grid-cols-3 gap-5">
            <div class="sm:col-span-12 md:col-span-1">
                <label for="title" class=""><?php echo e(__('Title')); ?> <span
                        class="text-red-600 ms-1 text-sm"><?php echo e(__('(REQUIRED)')); ?></span></label>
                <input type="text" id="title" name="title"
                    class="w-full block rounded mt-1 focus:shadow-none focus:ring-0 text-gray-600"
                    placeholder="Input Title" value="<?php echo e($task->title ?? old('title')); ?>">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-2 text-red-500"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="">
                <label for="start_date" class=""><?php echo e(__('Start Date')); ?> <span
                        class="text-red-600 ms-1 text-sm"><?php echo e(__('(REQUIRED)')); ?></span></label>
                <input type="date" id="start_date" name="start_date"
                    class="w-full block rounded mt-1 focus:shadow-none focus:ring-0 text-gray-600"
                    value="<?php echo e($task->start_date ?? old('start_date')); ?>">
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-2 text-red-500"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="">
                <label for="due_date" class=""><?php echo e(__('Due Date')); ?> <span
                        class="text-red-600 ms-1 text-sm"><?php echo e(__('(REQUIRED)')); ?></span></label>
                <input type="date" id="due_date" name="due_date"
                    class="w-full block rounded mt-1 focus:shadow-none focus:ring-0 text-gray-600"
                    value="<?php echo e($task->due_date ?? old('due_date')); ?>">
                <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-2 text-red-500"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-span-full">
                <label for="description" class=""><?php echo e(__('Description')); ?> <span
                        class="text-red-600 ms-1 text-sm"><?php echo e(__('(REQUIRED)')); ?></span></label>
                <textarea id="description" name="description"
                    class="w-full block rounded mt-1 focus:shadow-none focus:ring-0 text-gray-600" rows="5"
                    placeholder="Write down your description.."><?php echo e($task->description ?? old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-2 text-red-500"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-span-2">
                <label for="category" class=""><?php echo e(__('Category')); ?> <span
                        class="text-red-600 ms-1 text-sm"><?php echo e(__('(REQUIRED)')); ?></span></label>
                <?php
                    $empty = count(auth()->user()->categories) === 0 ? true : false;
                ?>

                <select name="category_id" id="category" class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'w-full block rounded mt-1 focus:shadow-none focus:ring-0',
                    'text-stone-400' => $empty,
                    'text-gray-600 uppercase' => !$empty,
                ]); ?>">
                    <option value="" selected disabled>Select a category</option>
                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($category->id); ?>"
                            <?php echo e(old('category_id') == $category->id || ($task->category_id ?? null) == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option value="" selected disabled class="text-white">
                            <?php echo e(__('No Category Available. Please create a category')); ?></option>
                    <?php endif; ?>

                </select>
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="mt-2 text-red-500"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="flex justify-end col-span-full">
                <button type="submit"
                    class="me-4 px-5 py-2 bg-blue-800 text-blue-200 rounded shadow"><?php echo e($update ? __('Update') : __('Create')); ?></button>
            </div>
        </div>

    </form>
</div>
<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\resources\views/components/tasks/form.blade.php ENDPATH**/ ?>