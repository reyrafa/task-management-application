<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['method', 'action', 'button' => 'Create', 'update' => null, 'name' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['method', 'action', 'button' => 'Create', 'update' => null, 'name' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<form method="<?php echo e($method); ?>" action="<?php echo e($action); ?>">
    <?php echo csrf_field(); ?>
    <?php if($update): ?>
        <?php echo method_field('put'); ?>
    <?php endif; ?>
    <div class="mt-3 w-3/4 mx-auto">
        <label for="name" class="block font-medium antialiased text-gray-700 mb-1">Name</label>
        <input type="text" name="name"
            class="block w-full rounded border-black focus:border-blue-500 focus:outline-none focus:ring-0"
            placeholder="Enter Name.." value="<?php echo e(strtoupper($name)); ?>" />
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-red-400 mt-1"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
    <div class="mt-3 w-3/4 mx-auto">
        <button class="p-2 text-white w-full bg-blue-800 rounded shadow"><?php echo e($button); ?></button>
    </div>
</form>
<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\resources\views/components/categories/form.blade.php ENDPATH**/ ?>