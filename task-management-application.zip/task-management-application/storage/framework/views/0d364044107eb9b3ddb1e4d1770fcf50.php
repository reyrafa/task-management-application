<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create Category')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="mt-7 container mx-auto p-5">
        <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
            <div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-200 " role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
        <div class="flex">
            <div
                class="bg-white w-full md:w-1/2 mx-auto p-1 sm:p-5 md:p-10 rounded-lg shadow-lg border-solid border border-indigo-300">
                <h1 class="text-center font-bold text-xl uppercase">Add Category</h1>
                <?php if (isset($component)) { $__componentOriginalf8c7b78f6dedc23ed651cda592260df3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8c7b78f6dedc23ed651cda592260df3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.categories.form','data' => ['method' => 'POST','action' => ''.e(route('categories.store')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('categories.form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['method' => 'POST','action' => ''.e(route('categories.store')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8c7b78f6dedc23ed651cda592260df3)): ?>
<?php $attributes = $__attributesOriginalf8c7b78f6dedc23ed651cda592260df3; ?>
<?php unset($__attributesOriginalf8c7b78f6dedc23ed651cda592260df3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8c7b78f6dedc23ed651cda592260df3)): ?>
<?php $component = $__componentOriginalf8c7b78f6dedc23ed651cda592260df3; ?>
<?php unset($__componentOriginalf8c7b78f6dedc23ed651cda592260df3); ?>
<?php endif; ?>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\resources\views/categories/create.blade.php ENDPATH**/ ?>