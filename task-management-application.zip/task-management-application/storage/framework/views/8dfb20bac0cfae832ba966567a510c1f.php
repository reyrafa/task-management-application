<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\rafae\Documents\projects\task-management-application\task-management-application\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>